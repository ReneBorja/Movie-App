//
//  AuthModel.swift
//  MovieApp
//
//  Created by Rene on 1/3/24.
//
import Foundation


struct AuthModel: Codable {
    let success: Bool
    let expiresAt, requestToken: String

    enum CodingKeys: String, CodingKey {
        case success
        case expiresAt = "expires_at"
        case requestToken = "request_token"
    }
}

struct AuthSessionModel: Codable {
    let success: Bool
    let sessionID: String

    enum CodingKeys: String, CodingKey {
        case success
        case sessionID = "session_id"
    }
}

struct logOut: Codable{
    let success: Bool
}
